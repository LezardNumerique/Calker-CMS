-- phpMyAdmin SQL Dump
-- version 3.3.2deb1ubuntu1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 22, 2012 at 06:46 PM
-- Server version: 5.1.63
-- PHP Version: 5.3.2-1ubuntu4.18

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `calker`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_captcha`
--

DROP TABLE IF EXISTS `ci_captcha`;
CREATE TABLE IF NOT EXISTS `ci_captcha` (
  `captcha_id` bigint(13) unsigned NOT NULL AUTO_INCREMENT,
  `captcha_time` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `word` varchar(20) NOT NULL,
  PRIMARY KEY (`captcha_id`),
  KEY `word` (`word`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ci_captcha`
--

INSERT INTO `ci_captcha` (`captcha_id`, `captcha_time`, `ip_address`, `word`) VALUES
(1, 1350767849, '192.168.1.12', '4768'),
(2, 1350767975, '192.168.1.12', '7731'),
(3, 1351352992, '192.168.1.9', '6169'),
(4, 1351378734, '192.168.1.12', '9438'),
(5, 1351938197, '192.168.1.12', '4555');

-- --------------------------------------------------------

--
-- Table structure for table `ci_contact`
--

DROP TABLE IF EXISTS `ci_contact`;
CREATE TABLE IF NOT EXISTS `ci_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(64) DEFAULT NULL,
  `lastname` varchar(64) DEFAULT NULL,
  `email` varchar(128) NOT NULL,
  `phone` varchar(16) DEFAULT NULL,
  `date` int(11) NOT NULL,
  `trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `phone` (`phone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ci_contact`
--


-- --------------------------------------------------------

--
-- Table structure for table `ci_contact_message`
--

DROP TABLE IF EXISTS `ci_contact_message`;
CREATE TABLE IF NOT EXISTS `ci_contact_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_id` int(11) NOT NULL,
  `types_id` int(1) NOT NULL,
  `subject` varchar(64) NOT NULL,
  `message` text NOT NULL,
  `date` int(11) NOT NULL,
  `trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `contact_id` (`contact_id`),
  KEY `types_id` (`types_id`),
  KEY `subject` (`subject`),
  KEY `trash` (`trash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ci_contact_message`
--


-- --------------------------------------------------------

--
-- Table structure for table `ci_groups`
--

DROP TABLE IF EXISTS `ci_groups`;
CREATE TABLE IF NOT EXISTS `ci_groups` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `ci_groups`
--

INSERT INTO `ci_groups` (`id`, `title`) VALUES
(1, 'root'),
(2, 'admin'),
(3, 'utilisateur');

-- --------------------------------------------------------

--
-- Table structure for table `ci_languages`
--

DROP TABLE IF EXISTS `ci_languages`;
CREATE TABLE IF NOT EXISTS `ci_languages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(5) NOT NULL,
  `name` varchar(64) NOT NULL,
  `ordering` int(5) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `default` tinyint(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `code` (`code`),
  KEY `name` (`name`),
  KEY `active` (`active`),
  KEY `default` (`default`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ci_languages`
--

INSERT INTO `ci_languages` (`id`, `code`, `name`, `ordering`, `active`, `default`) VALUES
(1, 'en', 'English', 1, 1, 0),
(2, 'fr', 'Français', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ci_medias`
--

DROP TABLE IF EXISTS `ci_medias`;
CREATE TABLE IF NOT EXISTS `ci_medias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(128) NOT NULL DEFAULT '',
  `file` varchar(128) NOT NULL DEFAULT '',
  `src_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(3) NOT NULL DEFAULT '0',
  `options` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`module`),
  KEY `src_id` (`src_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `ci_medias`
--

INSERT INTO `ci_medias` (`id`, `module`, `file`, `src_id`, `ordering`, `options`) VALUES
(14, 'portfolio_medias', 'portfolio-3-1349385108.jpg', 3, 0, ''),
(2, 'pages', 'calker-cms-gestionnaire-de-contenu-web-20-made-with-codeigniter-1_1349264066.jpg', 1, 0, 'a:6:{s:8:"position";s:4:"left";s:5:"ratio";s:4:"0.25";s:6:"legend";s:10:"Calker CMS";s:3:"alt";s:68:"Calker CMS - Gestionnaire de contenu Web 2.0 - Made with CODEIGNITER";s:4:"link";s:20:"http://www.calker.fr";s:6:"target";s:1:"1";}'),
(3, 'pages', 'agrandir-2_1349264488.jpg', 2, 0, 'a:7:{s:8:"position";s:5:"right";s:5:"ratio";s:4:"0.25";s:6:"legend";s:8:"Agrandir";s:3:"alt";s:8:"Agrandir";s:5:"popup";s:1:"1";s:4:"link";s:0:"";s:6:"target";s:1:"0";}'),
(4, 'pages', 'notre-equipe-dynamique-et-attentive-6_1349265509.jpg', 6, 0, 'a:6:{s:8:"position";s:6:"center";s:5:"ratio";s:1:"1";s:6:"legend";s:36:"Notre équipe dynamique et attentive";s:3:"alt";s:36:"Notre équipe dynamique et attentive";s:4:"link";s:0:"";s:6:"target";s:1:"0";}'),
(13, 'portfolio_medias', 'portfolio-2-1349385056.jpg', 2, 0, ''),
(11, 'pages', 'paragraph-7_1349347752.jpg', 7, 0, 'b:0;'),
(10, 'pages', 'paragraph-7_1349347670.jpg', 7, 1, 'b:0;'),
(12, 'portfolio_medias', 'portfolio-1-1349383895.jpg', 1, 0, ''),
(17, 'news', 'news-1-1349716561.jpg', 1, 0, ''),
(15, 'pages', 'eclipse-de-lune-9_1349886930.flv', 9, 0, 'a:4:{s:8:"position";s:4:"left";s:5:"ratio";s:1:"1";s:9:"autostart";s:1:"1";s:10:"fullscreen";s:1:"1";}'),
(16, 'news', 'news-2-1349716395.jpg', 2, 0, ''),
(18, 'portfolio_medias', 'portfolio-4-1349716789.jpg', 4, 0, ''),
(19, 'pages', 'paragraph-7_1349822924.jpg', 7, 2, 'b:0;');

-- --------------------------------------------------------

--
-- Table structure for table `ci_modules`
--

DROP TABLE IF EXISTS `ci_modules`;
CREATE TABLE IF NOT EXISTS `ci_modules` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `admin` tinyint(1) DEFAULT '0',
  `navigation` tinyint(1) DEFAULT '0',
  `version` varchar(5) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  `ordering` int(3) DEFAULT '0',
  `info` text,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `admin` (`admin`),
  KEY `active` (`active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ci_modules`
--

INSERT INTO `ci_modules` (`id`, `name`, `admin`, `navigation`, `version`, `active`, `ordering`, `info`, `description`) VALUES
(1, 'admin', 0, 0, '1.0.0', 1, -17, NULL, 'Admin core module'),
(2, 'pages', 1, 0, '1.0.0', 1, -16, NULL, 'Pages core module'),
(3, 'contact', 1, 0, '1.0.0', 1, 103, 'a:5:{s:4:"date";s:10:"09/12/2011";s:6:"author";s:13:"A.Polounovsky";s:5:"email";s:28:"contact@lezard-numerique.net";s:3:"url";s:31:"http://www.lezard-numerique.net";s:9:"copyright";s:9:"Copyright";}', 'Contact module'),
(4, 'portfolio', 1, 1, '1.0.0', 1, 102, 'a:5:{s:4:"date";s:10:"02/09/2012";s:6:"author";s:13:"A.Polounovsky";s:5:"email";s:28:"contact@lezard-numerique.net";s:3:"url";s:31:"http://www.lezard-numerique.net";s:9:"copyright";s:9:"Copyright";}', 'Portfolio module'),
(5, 'news', 1, 0, '1.0.0', 1, 101, 'a:5:{s:4:"date";s:10:"02/09/2012";s:6:"author";s:13:"A.Polounovsky";s:5:"email";s:28:"contact@lezard-numerique.net";s:3:"url";s:31:"http://www.lezard-numerique.net";s:9:"copyright";s:9:"Copyright";}', 'News module');

-- --------------------------------------------------------

--
-- Table structure for table `ci_navigation`
--

DROP TABLE IF EXISTS `ci_navigation`;
CREATE TABLE IF NOT EXISTS `ci_navigation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `ordering` int(3) DEFAULT '0',
  `module` varchar(64) DEFAULT NULL,
  `title` varchar(64) NOT NULL,
  `uri` varchar(128) DEFAULT NULL,
  `lang` char(5) NOT NULL DEFAULT 'fr',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `active` (`active`),
  KEY `weight` (`ordering`),
  KEY `uri` (`uri`),
  KEY `lang` (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `ci_navigation`
--

INSERT INTO `ci_navigation` (`id`, `parent_id`, `active`, `ordering`, `module`, `title`, `uri`, `lang`) VALUES
(1, 0, 1, 0, NULL, 'Menu Haut', 'menu-haut', 'fr'),
(2, 1, 1, 0, '', 'Accueil', 'index', 'fr'),
(3, 1, 1, 1, '', 'Découvrir', 'decouvrir', 'fr'),
(4, 1, 1, 2, NULL, 'Prestations', 'prestations', 'fr'),
(5, 1, 1, 4, '', 'News', 'news/index', 'fr'),
(6, 1, 1, 6, 'portfolio', 'Portfolio', 'portfolio/1/accueil/index', 'fr'),
(7, 1, 1, 7, NULL, 'Contact', 'contact', 'fr'),
(8, 0, 1, 0, '', 'Menu Bas', 'menu-bas', 'fr'),
(9, 8, 1, 1, '', 'Mentions légales', 'mentions-legales', 'fr'),
(10, 1, 1, 3, '', 'Equipe', 'equipe', 'fr'),
(11, 1, 1, 5, '', 'Vidéos', 'videos', 'fr'),
(12, 3, 1, 0, '', 'Les planètes', 'decouvrir/les-planetes', 'fr'),
(13, 3, 1, 0, '', 'Les satellites', 'decouvrir/les-satellites', 'fr'),
(14, 3, 1, 0, '', 'Les galaxies', 'decouvrir/les-galaxies', 'fr'),
(15, 3, 1, 0, '', 'Les nébuleuses', 'decouvrir/les-nebuleuses', 'fr'),
(16, 8, 1, 2, '', 'Contact', 'contact', 'fr'),
(17, 8, 1, 0, '', 'Accueil', 'index', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `ci_news`
--

DROP TABLE IF EXISTS `ci_news`;
CREATE TABLE IF NOT EXISTS `ci_news` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT '1',
  `date_added` int(11) DEFAULT NULL,
  `date_modified` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `active` (`active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ci_news`
--

INSERT INTO `ci_news` (`id`, `active`, `date_added`, `date_modified`) VALUES
(1, 0, 1349341934, 1349716561),
(2, 1, 1349342485, 1351959638);

-- --------------------------------------------------------

--
-- Table structure for table `ci_news_lang`
--

DROP TABLE IF EXISTS `ci_news_lang`;
CREATE TABLE IF NOT EXISTS `ci_news_lang` (
  `news_id` int(11) unsigned NOT NULL,
  `lang` char(5) NOT NULL DEFAULT 'fr',
  `title` varchar(128) DEFAULT NULL,
  `uri` varchar(128) NOT NULL,
  `body` text,
  `meta_title` varchar(128) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  UNIQUE KEY `news_id` (`news_id`,`lang`),
  KEY `uri` (`uri`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ci_news_lang`
--

INSERT INTO `ci_news_lang` (`news_id`, `lang`, `title`, `uri`, `body`, `meta_title`, `meta_keywords`, `meta_description`) VALUES
(1, 'fr', 'Lorem ipsum 2', 'lorem-ipsum-2', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>\n<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', '', '', ''),
(1, 'en', 'Lorem ipsum', 'lorem-ipsum', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>\n<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', '', '', ''),
(2, 'fr', 'Lorem ipsum', 'lorem-ipsum', '<p>Contrairement &agrave; une opinion r&eacute;pandue, le Lorem Ipsum n''est pas simplement du texte al&eacute;atoire. Il trouve ses racines dans une oeuvre de la litt&eacute;rature latine classique datant de 45 av. J.-C., le rendant vieux de 2000 ans. Un professeur du Hampden-Sydney College, en Virginie, s''est int&eacute;ress&eacute; &agrave; un des mots latins les plus obscurs, consectetur, extrait d''un passage du Lorem Ipsum, et en &eacute;tudiant tous les usages de ce mot dans la litt&eacute;rature classique, d&eacute;couvrit la source incontestable du Lorem Ipsum. Il provient en fait des sections 1.10.32 et 1.10.33 du "De Finibus Bonorum et Malorum" (Des Supr&ecirc;mes Biens et des Supr&ecirc;mes Maux) de Cic&eacute;ron. Cet ouvrage, tr&egrave;s populaire pendant la Renaissance, est un trait&eacute; sur la th&eacute;orie de l''&eacute;thique. Les premi&egrave;res lignes du Lorem Ipsum, "Lorem ipsum dolor sit amet...", proviennent de la section 1.10.32.</p>\n<p>Contrairement &agrave; une opinion r&eacute;pandue, le Lorem Ipsum n''est pas simplement du texte al&eacute;atoire. Il trouve ses racines dans une oeuvre de la litt&eacute;rature latine classique datant de 45 av. J.-C., le rendant vieux de 2000 ans. Un professeur du Hampden-Sydney College, en Virginie, s''est int&eacute;ress&eacute; &agrave; un des mots latins les plus obscurs, consectetur, extrait d''un passage du Lorem Ipsum, et en &eacute;tudiant tous les usages de ce mot dans la litt&eacute;rature classique, d&eacute;couvrit la source incontestable du Lorem Ipsum. Il provient en fait des sections 1.10.32 et 1.10.33 du "De Finibus Bonorum et Malorum" (Des Supr&ecirc;mes Biens et des Supr&ecirc;mes Maux) de Cic&eacute;ron. Cet ouvrage, tr&egrave;s populaire pendant la Renaissance, est un trait&eacute; sur la th&eacute;orie de l''&eacute;thique. Les premi&egrave;res lignes du Lorem Ipsum, "Lorem ipsum dolor sit amet...", proviennent de la section 1.10.32.</p>', '', '', ''),
(2, 'en', 'Lorem ipsum', 'lorem-ipsum', '<p>Contrairement &agrave; une opinion r&eacute;pandue, le Lorem Ipsum n''est pas simplement du texte al&eacute;atoire. Il trouve ses racines dans une oeuvre de la litt&eacute;rature latine classique datant de 45 av. J.-C., le rendant vieux de 2000 ans. Un professeur du Hampden-Sydney College, en Virginie, s''est int&eacute;ress&eacute; &agrave; un des mots latins les plus obscurs, consectetur, extrait d''un passage du Lorem Ipsum, et en &eacute;tudiant tous les usages de ce mot dans la litt&eacute;rature classique, d&eacute;couvrit la source incontestable du Lorem Ipsum. Il provient en fait des sections 1.10.32 et 1.10.33 du "De Finibus Bonorum et Malorum" (Des Supr&ecirc;mes Biens et des Supr&ecirc;mes Maux) de Cic&eacute;ron. Cet ouvrage, tr&egrave;s populaire pendant la Renaissance, est un trait&eacute; sur la th&eacute;orie de l''&eacute;thique. Les premi&egrave;res lignes du Lorem Ipsum, "Lorem ipsum dolor sit amet...", proviennent de la section 1.10.32.</p>\n<p>Contrairement &agrave; une opinion r&eacute;pandue, le Lorem Ipsum n''est pas simplement du texte al&eacute;atoire. Il trouve ses racines dans une oeuvre de la litt&eacute;rature latine classique datant de 45 av. J.-C., le rendant vieux de 2000 ans. Un professeur du Hampden-Sydney College, en Virginie, s''est int&eacute;ress&eacute; &agrave; un des mots latins les plus obscurs, consectetur, extrait d''un passage du Lorem Ipsum, et en &eacute;tudiant tous les usages de ce mot dans la litt&eacute;rature classique, d&eacute;couvrit la source incontestable du Lorem Ipsum. Il provient en fait des sections 1.10.32 et 1.10.33 du "De Finibus Bonorum et Malorum" (Des Supr&ecirc;mes Biens et des Supr&ecirc;mes Maux) de Cic&eacute;ron. Cet ouvrage, tr&egrave;s populaire pendant la Renaissance, est un trait&eacute; sur la th&eacute;orie de l''&eacute;thique. Les premi&egrave;res lignes du Lorem Ipsum, "Lorem ipsum dolor sit amet...", proviennent de la section 1.10.32.</p>', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ci_pages`
--

DROP TABLE IF EXISTS `ci_pages`;
CREATE TABLE IF NOT EXISTS `ci_pages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `ordering` int(3) DEFAULT '0',
  `title` varchar(128) DEFAULT NULL,
  `class` varchar(32) DEFAULT NULL,
  `uri` varchar(128) DEFAULT NULL,
  `lang` char(5) DEFAULT 'fr',
  `meta_title` varchar(128) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `show_sub_pages` tinyint(1) NOT NULL DEFAULT '0',
  `show_navigation` tinyint(1) NOT NULL DEFAULT '0',
  `date_added` int(11) NOT NULL,
  `date_modified` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uri` (`uri`),
  KEY `parent_id` (`parent_id`),
  KEY `active` (`active`),
  KEY `lang` (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `ci_pages`
--

INSERT INTO `ci_pages` (`id`, `parent_id`, `active`, `ordering`, `title`, `class`, `uri`, `lang`, `meta_title`, `meta_keywords`, `meta_description`, `show_sub_pages`, `show_navigation`, `date_added`, `date_modified`) VALUES
(1, 0, 1, 0, 'Bienvenue', '', 'index', 'fr', '', '', '', 0, 0, 0, 1349267350),
(2, 0, 1, 1, 'D&Atilde;&copy;couvrir', '', 'decouvrir', 'fr', '', '', '', 0, 0, 1349263107, 1349877897),
(3, 0, 1, 2, 'Prestations', '', 'prestations', 'fr', '', '', '', 0, 0, 1349263198, NULL),
(4, 0, 1, 5, 'Mentions l&Atilde;&copy;gales', '', 'mentions-legales', 'fr', '', '', '', 0, 0, 0, 1349265115),
(5, 0, 1, 3, 'Equipe', '', 'equipe', 'fr', '', '', '', 0, 0, 0, 1349265444),
(6, 0, 1, 4, 'Vid&Atilde;&copy;os', '', 'videos', 'fr', '', '', '', 0, 0, 1349546776, NULL),
(7, 2, 1, 0, 'Les plan&Atilde;&uml;tes', '', 'decouvrir/les-planetes', 'fr', '', '', '', 0, 0, 1349640716, 1349878001),
(8, 2, 1, 3, 'Les n&Atilde;&copy;buleuses', '', 'decouvrir/les-nebuleuses', 'fr', '', '', '', 0, 0, 1349640741, 1349878325),
(9, 2, 1, 1, 'Les satellites', '', 'decouvrir/les-satellites', 'fr', '', '', '', 0, 0, 1349878166, 1349878183),
(10, 2, 1, 2, 'Les galaxies', '', 'decouvrir/les-galaxies', 'fr', '', '', '', 0, 0, 1349878286, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ci_paragraphs`
--

DROP TABLE IF EXISTS `ci_paragraphs`;
CREATE TABLE IF NOT EXISTS `ci_paragraphs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(32) DEFAULT NULL,
  `class_2` varchar(32) DEFAULT NULL,
  `class_3` varchar(32) DEFAULT NULL,
  `src_id` int(11) NOT NULL,
  `types_id` int(11) DEFAULT NULL,
  `module` varchar(64) NOT NULL,
  `active` tinyint(1) DEFAULT '1',
  `ordering` int(3) DEFAULT '0',
  `title` varchar(128) DEFAULT NULL,
  `title_2` varchar(128) DEFAULT NULL,
  `title_3` varchar(128) DEFAULT NULL,
  `lang` char(5) NOT NULL DEFAULT 'fr',
  `body` longtext,
  `body_2` longtext,
  `body_3` longtext,
  `date_added` int(11) NOT NULL,
  `date_modified` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `src_id` (`src_id`),
  KEY `types_id` (`types_id`),
  KEY `module` (`module`),
  KEY `active` (`active`),
  KEY `lang` (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `ci_paragraphs`
--

INSERT INTO `ci_paragraphs` (`id`, `class`, `class_2`, `class_3`, `src_id`, `types_id`, `module`, `active`, `ordering`, `title`, `title_2`, `title_3`, `lang`, `body`, `body_2`, `body_3`, `date_added`, `date_modified`) VALUES
(1, '', NULL, NULL, 2, 3, 'pages', 1, 0, 'Pourquoi l''utiliser ?', NULL, NULL, 'fr', '<p>On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de distractions, et emp&ecirc;che de se concentrer sur la mise en page elle-m&ecirc;me. L''avantage du Lorem Ipsum sur un texte g&eacute;n&eacute;rique comme ''Du texte. Du texte. Du texte.'' est qu''il poss&egrave;de une distribution de lettres plus ou moins normale, et en tout cas comparable avec celle du fran&ccedil;ais standard. De nombreuses suites logicielles de mise en page ou &eacute;diteurs de sites Web ont fait du Lorem Ipsum leur faux texte par d&eacute;faut, et une recherche pour ''Lorem Ipsum'' vous conduira vers de nombreux sites qui n''en sont encore qu''&agrave; leur phase de construction. Plusieurs versions sont apparues avec le temps, parfois par accident, souvent intentionnellement (histoire d''y rajouter de petits clins d''oeil, voire des phrases embarassantes).</p>', NULL, NULL, 1349263838, 1349264066),
(2, '', NULL, NULL, 3, 3, 'pages', 1, 0, 'Ou puis je m''en procurer ?', NULL, NULL, 'fr', '<p>Plusieurs variations de Lorem Ipsum peuvent &ecirc;tre trouv&eacute;es ici ou l&agrave;, mais la majeure partie d''entre elles a &eacute;t&eacute; alt&eacute;r&eacute;e par l''addition d''humour ou de mots al&eacute;atoires qui ne ressemblent pas une seconde &agrave; du texte standard. Si vous voulez utiliser un passage du Lorem Ipsum, vous devez &ecirc;tre s&ucirc;r qu''il n''y a rien d''embarrassant cach&eacute; dans le texte. Tous les g&eacute;n&eacute;rateurs de Lorem Ipsum sur Internet tendent &agrave; reproduire le m&ecirc;me extrait sans fin, ce qui fait de lipsum.com le seul vrai g&eacute;n&eacute;rateur de Lorem Ipsum. Iil utilise un dictionnaire de plus de 200 mots latins, en combinaison de plusieurs structures de phrases, pour g&eacute;n&eacute;rer un Lorem Ipsum irr&eacute;prochable. Le Lorem Ipsum ainsi obtenu ne contient aucune r&eacute;p&eacute;tition, ni ne contient des mots farfelus, ou des touches d''humour.</p>', NULL, NULL, 1349264488, NULL),
(3, '', '', '', 3, 8, 'pages', 1, 0, 'Titre 1', 'Titre 2', 'Titre 3', 'fr', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', 1349264594, NULL),
(4, '', '', NULL, 2, 7, 'pages', 1, 0, 'Titre 1', 'Titre 2', NULL, 'fr', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', NULL, 1349264662, 1349264718),
(5, '', NULL, NULL, 4, 1, 'pages', 1, 0, '', NULL, NULL, 'fr', '<div class="cms_row">\n<h2><span>1. Informations l&eacute;gales</span></h2>\n<div class="cms_row_inner">\n<p>Conform&eacute;ment aux dispositions des articles 6-III et 19 de la loi pour la Confiance dans l''&Eacute;conomie Num&eacute;rique, nous vous informons que&nbsp;:</p>\n<ul>\n<li>Le pr&eacute;sent site web est &eacute;dit&eacute; par&nbsp;:<br />L&eacute;zard Num&eacute;rique - Alexandre Polounovsky<br />Num&eacute;ro Siret&nbsp;: 50766540400038 - Ursaff de Nice<br />Si&egrave;ge social: 14 avenue de Nice - 06600 Antibes<br />T&eacute;l :<span style="color: #000000;">06 43 52 88 31</span></li>\n<li>Le directeur de la publication du site web est Alexandre POLOUNOVSKY</li>\n<li>Le prestataire assurant le stockage direct et permanent est&nbsp;:<br />OVH<br />SAS au capital de 5 000 000 &euro; <br />Si&egrave;ge social : 2 rue Kellermann - 59100 Roubaix - France.<br />RCS Roubaix &ndash; Tourcoing 424 761 419 00045 Code APE 6202A<br />N&deg; TVA : FR 22 424 761 419</li>\n</ul>\n</div>\n</div>\n<div class="cms_row">\n<h2 class="0"><span>2. Limitation de responsabilit&eacute;</span></h2>\n<div class="cms_row_inner">\n<p>L''utilisateur reconna&icirc;t avoir pris connaissance des pr&eacute;sentes conditions d''utilisation et s''engage &agrave; les respecter.</p>\n<p>L''utilisateur du site internet "www.lezard-numerique.net" reconna&icirc;t disposer de la comp&eacute;tence et des moyens n&eacute;cessaires pour acc&eacute;der et utiliser ce site.</p>\n<p>L''utilisateur du site internet "www.lezard-numerique.net" reconna&icirc;t avoir v&eacute;rifi&eacute; que la configuration informatique utilis&eacute;e ne contient aucun virus et qu''elle est en parfait &eacute;tat de fonctionnement.</p>\n<p>L&eacute;zard Num&eacute;rique met tout en &oelig;uvre pour offrir aux utilisateurs des informations et/ou des outils disponibles et v&eacute;rifi&eacute;s mais ne saurait &ecirc;tre tenue pour responsable des erreurs, d''une absence de disponibilit&eacute; des fonctionnalit&eacute;s et/ou de la pr&eacute;sence de virus sur son site.</p>\n<p>Les informations fournies par L&eacute;zard Num&eacute;rique le sont &agrave; titre indicatif et ne sauraient dispenser l''utilisateur d''une analyse compl&eacute;mentaire et personnalis&eacute;e.</p>\n<p>L&eacute;zard Num&eacute;rique ne saurait garantir l''exactitude, la compl&eacute;tude, l''actualit&eacute; des informations diffus&eacute;es sur son site.</p>\n<p>En cons&eacute;quence, l''utilisateur reconna&icirc;t utiliser ces informations sous sa responsabilit&eacute; exclusive.</p>\n</div>\n</div>\n<div class="cms_row">\n<h2 class="0"><span>3. Informatique et Libert&eacute;s</span></h2>\n<div class="cms_row_inner">\n<p>En application de la loi n&deg;78-17 du 6 janvier 1978 modifi&eacute;e, relative &agrave; l''informatique, aux fichiers et aux libert&eacute;s, le site web a fait l''objet d''une d&eacute;claration aupr&egrave;s de la Commission Nationale de l''Informatique et des Libert&eacute;s(<a href="http://www.cnil.fr/" target="_blank">www.cnil.fr</a>), sous le num&eacute;ro <strong>1462175</strong> .</p>\n<p>Les traitements automatis&eacute;s de donn&eacute;es nominatives r&eacute;alis&eacute;s &agrave; partir du site web "L&eacute;zard Num&eacute;rique" ont &eacute;t&eacute; trait&eacute;s en conformit&eacute; avec les exigences de la loi n&deg;78-17 du 6 janvier 1978 modifi&eacute;e, relative &agrave; l''informatique, aux fichiers et aux libert&eacute;s.</p>\n<p>L''utilisateur est notamment inform&eacute; que conform&eacute;ment &agrave; l''article 32 de la loi n&deg;78-17 du 6 janvier 1978 modifi&eacute;e, relative &agrave; l''informatique, aux fichiers et aux libert&eacute;s, les informations qu''il communique par le biais des formulaires pr&eacute;sents sur le site sont n&eacute;cessaires pour r&eacute;pondre &agrave; sa demande et sont destin&eacute;es &agrave; L&eacute;zard Num&eacute;rique, en tant que responsable du traitement &agrave; des fins de gestion administrative et commerciale.</p>\n<p>L''utilisateur est inform&eacute; qu''il dispose d''un droit d''acc&egrave;s, d''interrogation et de rectification qui lui permet, le cas &eacute;ch&eacute;ant, de faire rectifier, compl&eacute;ter, mettre &agrave; jour, verrouiller ou effacer les donn&eacute;es personnelles le concernant qui sont inexactes, incompl&egrave;tes, &eacute;quivoques, p&eacute;rim&eacute;es ou dont la collecte, l''utilisation, la communication ou la conservation est interdite.</p>\n<p>L''utilisateur dispose &eacute;galement d''un droit d''opposition au traitement de ses donn&eacute;es pour des motifs l&eacute;gitimes ainsi qu''un droit d''opposition &agrave; ce que ces donn&eacute;es soient utilis&eacute;es &agrave; des fins de prospection commerciale.</p>\n<p>L''ensemble de ces droits s''exerce aupr&egrave;s de <a href="http://www.lezard-numerique.net/contact">L&eacute;zard Num&eacute;rique</a> par courrier accompagn&eacute; d''une copie d''un titre d''identit&eacute; comportant une signature &agrave; adresser &agrave;&nbsp;:</p>\n<p>L&eacute;zard Num&eacute;rique - Alexandre Polounovsky<br />Service des affaires juridiques<br />14 avenue de Nice<br />06600 Antibes<br />France</p>\n</div>\n</div>\n<div class="cms_row">\n<h2 class="0"><span>4. Cookies</span></h2>\n<div class="cms_row_inner">\n<p>L''utilisateur est inform&eacute; que lors de ses visites sur le site, un cookie peut s''installer automatiquement sur son logiciel de navigation.</p>\n<p>Le cookie est un bloc de donn&eacute;es qui ne permet pas d''identifier les utilisateurs mais sert &agrave; enregistrer des informations relatives &agrave; la navigation de celui-ci sur le site.</p>\n<p>Le param&eacute;trage du logiciel de navigation permet d''informer de la pr&eacute;sence de cookie et &eacute;ventuellement, de la refuser de la mani&egrave;re d&eacute;crite &agrave; l''adresse suivante&nbsp;: <a href="http://www.cnil.fr/" target="_blank">www.cnil.fr</a>.</p>\n<p>L''utilisateur dispose de l''ensemble des droits susvis&eacute;s s''agissant des donn&eacute;es &agrave; caract&egrave;re personnel communiqu&eacute;es par le biais des cookies dans les conditions indiqu&eacute;es ci-dessus.</p>\n<p>Les utilisateurs du site internet "www.lezard-numerique.net" sont tenus de respecter les dispositions de la loi n&deg;78-17 du 6 janvier 1978 modifi&eacute;e, relative &agrave; l''informatique, aux fichiers et aux libert&eacute;s, dont la violation est passible de sanctions p&eacute;nales.</p>\n<p>Ils doivent notamment s''abstenir, s''agissant des informations &agrave; caract&egrave;re personnel auxquelles ils acc&egrave;dent ou pourraient acc&eacute;der, de toute collecte, de toute utilisation d&eacute;tourn&eacute;e d''une mani&egrave;re g&eacute;n&eacute;rale, de tout acte susceptible de porter atteinte &agrave; la vie priv&eacute;e ou &agrave; la r&eacute;putation des personnes.</p>\n</div>\n</div>\n<div class="cms_row last">\n<h2 class="0"><span>5. Propri&eacute;t&eacute; intellectuelle</span></h2>\n<div class="cms_row_inner">\n<p>La structure g&eacute;n&eacute;rale ainsi que les logiciels, textes, images anim&eacute;es ou non, son savoir-faire et tous les autres &eacute;l&eacute;ments composant le site sont la propri&eacute;t&eacute; exclusive de L&eacute;zard Num&eacute;rique.</p>\n<p>Toute repr&eacute;sentation totale ou partielle de ce site par quelle que personne que ce soit, sans l''autorisation expresse de L&eacute;zard Num&eacute;rique est interdite et constituerait une contrefa&ccedil;on sanctionn&eacute;e par les articles L. 335-2 et suivants du Code de la propri&eacute;t&eacute; intellectuelle.</p>\n<p>Il en est de m&ecirc;me des bases de donn&eacute;es figurant, le cas &eacute;ch&eacute;ant sur le site web qui sont prot&eacute;g&eacute;es par les dispositions de la loi du 1er juillet 1998 portant transposition dans le Code de la propri&eacute;t&eacute; intellectuelle de la directive du 11 mars 1996 relative &agrave; la protection juridique des bases de donn&eacute;es, et dont L&eacute;zard Num&eacute;rique est producteur.</p>\n<p>Les marques de L&eacute;zard Num&eacute;rique et de ses partenaires, ainsi que les logos figurant sur le site sont des marques d&eacute;pos&eacute;es.</p>\n<p>Toute reproduction totale ou partielle de ces marques ou de ces logos effectu&eacute;s &agrave; partir des &eacute;l&eacute;ments du site sans l''autorisation expresse de L&eacute;zard Num&eacute;rique est donc prohib&eacute;e au sens du Code de la propri&eacute;t&eacute; intellectuelle.</p>\n<p>L&eacute;zard Num&eacute;rique ne saurait &ecirc;tre responsable de l''acc&egrave;s par les utilisateurs via les liens hypertextes mis en place dans le cadre du site internet en direction d''autres ressources pr&eacute;sentes sur le r&eacute;seau.</p>\n<p>Tout litige en relation avec l''utilisation du site "www.lezard-numerique.net" est soumis au droit fran&ccedil;ais. L''utilisateur reconna&icirc;t la comp&eacute;tence exclusive des tribunaux comp&eacute;tents de Grasse.</p>\n<p><strong>&copy;</strong>www.lezard-numerique.net<strong> 2005-2012</strong></p>\n</div>\n</div>', NULL, NULL, 1349265178, 1349265248),
(6, '', NULL, NULL, 5, 2, 'pages', 1, 0, '', NULL, NULL, 'fr', NULL, NULL, NULL, 1349265509, NULL),
(7, NULL, NULL, NULL, 1, 9, 'pages', 1, 0, NULL, NULL, NULL, 'fr', NULL, NULL, NULL, 1349265854, 1349822924),
(8, '', NULL, NULL, 1, 1, 'pages', 1, 0, 'Calker CMS', NULL, NULL, 'fr', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', NULL, NULL, 1349266997, 1349267318),
(9, '', NULL, NULL, 6, 6, 'pages', 1, 0, 'Eclipse de Lune', NULL, NULL, 'fr', NULL, NULL, NULL, 1349547203, 1349886930);

-- --------------------------------------------------------

--
-- Table structure for table `ci_paragraphs_types`
--

DROP TABLE IF EXISTS `ci_paragraphs_types`;
CREATE TABLE IF NOT EXISTS `ci_paragraphs_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `module` varchar(64) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `ci_paragraphs_types`
--

INSERT INTO `ci_paragraphs_types` (`id`, `code`, `module`, `active`) VALUES
(1, 'text', 'pages', 1),
(2, 'image', 'pages', 1),
(3, 'text_image', 'pages', 1),
(4, 'galery', 'pages', 0),
(5, 'flash', 'pages', 1),
(6, 'videos', 'pages', 1),
(7, 'text_2_cols', 'pages', 1),
(8, 'text_3_cols', 'pages', 1),
(9, 'slider_img', 'pages', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ci_portfolio_categories`
--

DROP TABLE IF EXISTS `ci_portfolio_categories`;
CREATE TABLE IF NOT EXISTS `ci_portfolio_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `ordering` int(3) DEFAULT '0',
  `date_added` int(11) NOT NULL,
  `date_modified` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `active` (`active`),
  KEY `parent_id` (`parent_id`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ci_portfolio_categories`
--

INSERT INTO `ci_portfolio_categories` (`id`, `parent_id`, `active`, `ordering`, `date_added`, `date_modified`) VALUES
(1, 0, 1, 0, 1349260215, NULL),
(2, 1, 1, 0, 1349383741, 1349641400),
(3, 1, 1, 0, 1349383786, 1349692047),
(4, 1, 1, 0, 1349383802, 1349550897),
(5, 2, 1, 0, 1349632618, 1349632623);

-- --------------------------------------------------------

--
-- Table structure for table `ci_portfolio_categories_lang`
--

DROP TABLE IF EXISTS `ci_portfolio_categories_lang`;
CREATE TABLE IF NOT EXISTS `ci_portfolio_categories_lang` (
  `categories_id` int(11) NOT NULL,
  `lang` char(5) NOT NULL DEFAULT 'fr',
  `title` varchar(64) NOT NULL,
  `body` text,
  `meta_title` varchar(64) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `uri` varchar(64) NOT NULL,
  UNIQUE KEY `categories_id` (`categories_id`,`lang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ci_portfolio_categories_lang`
--

INSERT INTO `ci_portfolio_categories_lang` (`categories_id`, `lang`, `title`, `body`, `meta_title`, `meta_keywords`, `meta_description`, `uri`) VALUES
(1, 'fr', 'Portfolio', NULL, NULL, NULL, NULL, 'accueil'),
(1, 'en', 'Portfolio', NULL, NULL, NULL, NULL, 'home'),
(3, 'en', 'Plan&Atilde;&uml;tes', '', '', '', '', 'planetes'),
(3, 'fr', 'Plan&Atilde;&uml;tes', '', '', '', '', 'planetes'),
(2, 'fr', 'Lunaire', '', '', '', '', 'lunaire'),
(2, 'en', 'Lunaire', '', '', '', '', 'lunaire'),
(4, 'fr', 'Ciel Profond', '', '', '', '', 'ciel-profond'),
(4, 'en', 'Ciel Profond', '', '', '', '', 'ciel-profond'),
(5, 'fr', 'Divers', '', '', '', '', 'divers'),
(5, 'en', 'Divers', '', '', '', '', 'divers');

-- --------------------------------------------------------

--
-- Table structure for table `ci_portfolio_categories_to_medias`
--

DROP TABLE IF EXISTS `ci_portfolio_categories_to_medias`;
CREATE TABLE IF NOT EXISTS `ci_portfolio_categories_to_medias` (
  `medias_id` int(11) NOT NULL DEFAULT '0',
  `categories_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`medias_id`,`categories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ci_portfolio_categories_to_medias`
--

INSERT INTO `ci_portfolio_categories_to_medias` (`medias_id`, `categories_id`, `ordering`) VALUES
(1, 2, 0),
(1, 1, 0),
(2, 1, 0),
(2, 3, 0),
(3, 1, 0),
(3, 3, 0),
(4, 1, 0),
(4, 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ci_portfolio_medias`
--

DROP TABLE IF EXISTS `ci_portfolio_medias`;
CREATE TABLE IF NOT EXISTS `ci_portfolio_medias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT '1',
  `is_box` tinyint(1) DEFAULT '1',
  `categories_id_default` int(11) NOT NULL DEFAULT '1',
  `file` varchar(128) DEFAULT NULL,
  `date_added` int(11) DEFAULT NULL,
  `date_modified` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `active` (`active`),
  KEY `is_box` (`is_box`),
  KEY `categories_id_default` (`categories_id_default`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ci_portfolio_medias`
--

INSERT INTO `ci_portfolio_medias` (`id`, `active`, `is_box`, `categories_id_default`, `file`, `date_added`, `date_modified`) VALUES
(1, 1, 1, 2, 'portfolio-1-1349383895.jpg', 1349383895, 1349383910),
(2, 1, 1, 3, 'portfolio-2-1349385056.jpg', 1349385056, NULL),
(3, 1, 1, 3, 'portfolio-3-1349385108.jpg', 1349385108, NULL),
(4, 1, 1, 4, 'portfolio-4-1349716789.jpg', 1349716789, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ci_portfolio_medias_lang`
--

DROP TABLE IF EXISTS `ci_portfolio_medias_lang`;
CREATE TABLE IF NOT EXISTS `ci_portfolio_medias_lang` (
  `medias_id` int(11) unsigned NOT NULL,
  `lang` char(5) NOT NULL DEFAULT 'fr',
  `title` varchar(64) NOT NULL,
  `body` text,
  `uri` varchar(64) NOT NULL,
  `legend` varchar(128) DEFAULT NULL,
  `alt` varchar(128) DEFAULT NULL,
  UNIQUE KEY `medias_id` (`medias_id`,`lang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ci_portfolio_medias_lang`
--

INSERT INTO `ci_portfolio_medias_lang` (`medias_id`, `lang`, `title`, `body`, `uri`, `legend`, `alt`) VALUES
(1, 'fr', 'Lune', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', 'lune', 'Alexandre Polounovsky', 'Lune'),
(1, 'en', 'Lune', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', 'lune', 'Alexandre Polounovsky', 'Lune'),
(2, 'fr', 'Saturne', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', 'saturne', 'Alexandre Polounovsky', 'Saturne'),
(2, 'en', 'Saturne', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', 'saturne', 'Alexandre Polounovsky', 'Saturne'),
(3, 'fr', 'Jupiter', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', 'jupiter', 'Alexandre Polounovsky', 'Jupiter'),
(3, 'en', 'Jupiter', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', 'jupiter', 'Alexandre Polounovsky', 'Jupiter'),
(4, 'fr', 'M42', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', 'm42', 'Alexandre Polounovsky', 'M42'),
(4, 'en', 'M42', '<p>Le <strong>Lorem Ipsum</strong> est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l''imprimerie depuis les ann&eacute;es 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n''a pas fait que survivre cinq si&egrave;cles, mais s''est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n''en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', 'm42', 'Alexandre Polounovsky', 'M42');

-- --------------------------------------------------------

--
-- Table structure for table `ci_rights`
--

DROP TABLE IF EXISTS `ci_rights`;
CREATE TABLE IF NOT EXISTS `ci_rights` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groups_id` int(3) NOT NULL,
  `module` varchar(64) NOT NULL DEFAULT '',
  `level` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `groups_id` (`groups_id`),
  KEY `module` (`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `ci_rights`
--

INSERT INTO `ci_rights` (`id`, `groups_id`, `module`, `level`) VALUES
(1, 1, 'admin', 4),
(2, 2, 'admin', 4),
(3, 1, 'pages', 4),
(4, 2, 'pages', 4),
(5, 1, 'contact', 4),
(6, 2, 'contact', 4),
(7, 1, 'portfolio', 4),
(8, 2, 'portfolio', 4),
(9, 1, 'news', 4),
(10, 2, 'news', 4);

-- --------------------------------------------------------

--
-- Table structure for table `ci_settings`
--

DROP TABLE IF EXISTS `ci_settings`;
CREATE TABLE IF NOT EXISTS `ci_settings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT '0',
  `value` text,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=146 ;

--
-- Dumping data for table `ci_settings`
--

INSERT INTO `ci_settings` (`id`, `name`, `value`) VALUES
(1, 'site_email', 'contact@lezard-numerique.net'),
(6, 'cache', '0'),
(9, 'debug', '1'),
(12, 'google_analytic_ga_id', 'ga:51831747'),
(15, 'logo', 'logo.png'),
(18, 'maintenance', '0'),
(20, 'meta_more', 'Gestionnaire de contenu Web'),
(21, 'meta_keywords', 'cms,content,management,system,modulaire,wysiwyg,codeigniter,ci-cms,site,internet,videos,photos,gallery,forms,formulaires,catalog,catalogue,shop,ecommerce,newsletters,bannières,vitrine,gestionnaire,contenu'),
(22, 'meta_description', 'Calker CMS - Gestionnaire de contenu Web 2.0 - Made with CODEIGNITER'),
(31, 'site_adress', '7 Allée des phalènes'),
(32, 'site_city', 'ANTIBES'),
(34, 'site_phone', '0643528831'),
(35, 'site_post_code', '06600'),
(36, 'site_name', 'Calker CMS'),
(39, 'stylesheet', 'style.css'),
(42, 'tiny_config', 'bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyfull,|,bullist,numlist,|,link,unlink,|,fontsizeselect,formatselect,|,undo,redo,image|,cleanup,removeformat,code,filemanager'),
(45, 'version', '2.0'),
(48, 'theme', 'theme1'),
(49, 'site_country', 'FRANCE'),
(51, 'per_page', '20'),
(52, 'ip_allow', '0'),
(53, 'cache_css', '0'),
(54, 'cache_time', '0'),
(56, 'per_captcha', '4'),
(57, 'google_analytic_ua_id', 'UA-19531658-1'),
(58, 'num_links', '5'),
(60, 'quality_img', '100'),
(62, 'pages_settings', 'a:3:{s:9:"page_home";s:5:"index";s:17:"page_publish_feed";s:1:"1";s:8:"per_page";s:2:"10";}'),
(68, 'site_adress_next', 'Résidence les balcons du port'),
(74, 'google_analytics_email', 'contact@lezard-numerique.net'),
(75, 'google_analytics_password', 'agtpGhWh'),
(76, 'google_analytic_domain', 'http://www.domain.com'),
(79, 'smtp_host', '91.212.26.180'),
(80, 'smtp_username', 'contact@domain.com'),
(81, 'smtp_password', ''),
(82, 'smtp_port', '25'),
(83, 'smtp_is', '0'),
(138, 'google_analytic_code', ''),
(136, 'site_schedule', 'Ouvert du Lundi au Vendredi\nDe 9h30 à 18h30'),
(139, 'google_analytic_stats', '1'),
(140, 'google_analytic_visits', '1'),
(142, 'contact_settings', 'a:9:{s:16:"per_page_contact";s:2:"20";s:22:"active_field_firstname";s:1:"1";s:21:"active_field_lastname";s:1:"1";s:18:"active_field_phone";s:1:"1";s:20:"active_field_message";s:1:"1";s:11:"active_form";s:1:"1";s:10:"active_map";s:1:"1";s:12:"active_coord";s:1:"1";s:13:"active_qrcode";s:1:"1";}'),
(143, 'portfolio_settings', 'a:4:{s:22:"publish_feed_portfolio";s:1:"1";s:13:"box_portfolio";s:1:"1";s:24:"per_portfolio_categories";s:2:"20";s:20:"per_portfolio_medias";s:2:"20";}'),
(144, 'news_settings', 'a:5:{s:17:"publish_feed_news";s:1:"1";s:8:"box_news";s:1:"1";s:13:"per_page_news";s:1:"1";s:16:"substr_home_news";s:3:"400";s:19:"substr_listing_news";s:3:"800";}'),
(145, 'active_visits', '0');

-- --------------------------------------------------------

--
-- Table structure for table `ci_users`
--

DROP TABLE IF EXISTS `ci_users`;
CREATE TABLE IF NOT EXISTS `ci_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groups_id` int(3) NOT NULL,
  `username` varchar(12) DEFAULT NULL,
  `password` varchar(50) DEFAULT '',
  `email` varchar(128) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `lastvisit` int(11) DEFAULT '0',
  `registered` int(11) DEFAULT '0',
  `online` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `groups_id` (`groups_id`),
  KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `online` (`online`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `ci_users`
--

INSERT INTO `ci_users` (`id`, `groups_id`, `username`, `password`, `email`, `active`, `lastvisit`, `registered`, `online`) VALUES
(1, 1, 'root', '60c00a67f838ec77fc6ac3d7df57e18115c12709', 'contact@lezard-numerique.net', 1, 1351971019, 1303587380, 1),
(2, 2, 'admin', '2bc5d99d425304c30e9c5af79a1482b5b6114cbf', 'admin@lezard-numerique.net', 1, 1351937745, 1315319295, 1),
(3, 3, 'john', '2bc5d99d425304c30e9c5af79a1482b5b6114cbf', 'johndoe@test.fr', 1, 1349305667, 1315326074, 1);
